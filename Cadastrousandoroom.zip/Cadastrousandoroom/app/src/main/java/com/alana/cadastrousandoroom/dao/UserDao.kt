package com.alana.cadastrousandoroom.dao

import androidx.lifecycle.LiveData
import com.alana.cadastrousandoroom.model.User

@Dao
interface UserDao {
    @Query("SELECT * FROM users")
    suspend fun getAll(): List<User>

    @Insert
    suspend fun insert(user: User)
}

